Clockwork LFSR — CTF Crypto Challenge
====================================

Overview
--------
This is a seeded Clockwork LFSR stream-cipher challenge. Players are provided with:
- cipher.bin : 1 MiB of ciphertext (raw bytes)
- meta.txt   : algorithm and parameter specifications (KDF parameters, LFSR lengths, combiner, etc.)
- clues.txt  : five puzzle clues; solving them yields a 5-word seed phrase used to initialize the LFSRs

Objective
---------
Recover the hidden flag that was embedded into the plaintext at known offsets (see meta.txt and clues).
The KDF-derived key (hex) can be used for verification once players produce a candidate plaintext.

How to submit
-------------
The flag format is standard CTF format: FLAG{...}. When you recover the flag, submit it through the competition scoreboard or send it to the challenge author.

Hints & workflow
----------------
1. Read meta.txt to learn LFSR sizes, combiner function description, KDF salt/iterations, and where the plaintext was embedded.
2. Solve the five clues in clues.txt to recover the seed phrase (words joined by '|'). The seed phrase seeds the LFSRs (see meta.txt).
3. Use the starter solver_tools in solver_tools/ to:
   - perform correlation attacks,
   - test LFSR taps,
   - derive the stream key,
   - decrypt and inspect plaintext samples.
4. Validate your recovered KDF output (hex) against dk_hex.txt (setter-only).
5. Look at plaintext_sample.bin (setter-only) to sanity-check recovered keystream for first 2048 bytes.

Files included
--------------
Public:
  - cipher.bin
  - meta.txt
  - clues.txt
  - solver_tools/ (starter scripts)
  - README.txt (this file)


Good luck — may the best crypto-solver win!
