# lfsr_tools.py
# Helper functions for LFSR generation and testing.
# Provides a simple LFSR class with arbitrary tap positions and bit ordering.
from typing import List

class LFSR:
    def __init__(self, length: int, taps: List[int], seed: int):
        self.length = length
        self.taps = taps  # tap positions as integers 0..length-1 (0 is MSB)
        self.state = seed & ((1<<length)-1)

    def step(self):
        # compute feedback as XOR of tap bits
        fb = 0
        for t in self.taps:
            fb ^= (self.state >> (self.length-1 - t)) & 1
        out = (self.state >> (self.length-1)) & 1
        self.state = ((self.state << 1) & ((1<<self.length)-1)) | fb
        return out

    def keystream(self, nbits):
        for _ in range(nbits):
            yield self.step()

    def state_hex(self):
        return hex(self.state)

if __name__ == '__main__':
    # tiny self-test
    l = LFSR(5, [0,2], seed=0b10011)
    ks = ''.join(str(next(l.keystream(1))) for _ in range(16))
    print('keystream(16)=', ks)
