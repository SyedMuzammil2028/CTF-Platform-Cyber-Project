# correlation_test.py
# Simple starter script to compute bitwise correlation between ciphertext stream and candidate LFSR output.
# Usage example:
#   python3 correlation_test.py /mnt/data/challenge_pack/cipher.bin candidate_keystream.bin
import sys
import os

def read_bytes(path, n=None):
    with open(path, "rb") as f:
        data = f.read() if n is None else f.read(n)
    return data

def bits_from_bytes(b):
    for byte in b:
        for i in range(8):
            yield (byte >> (7-i)) & 1

def correlation(cipher_bits, keystream_bits):
    # compute fraction of equal bits (simple correlation)
    matches = sum(1 for a,b in zip(cipher_bits, keystream_bits) if a == b)
    total = sum(1 for _ in zip(cipher_bits, keystream_bits))
    return matches, total, matches/total if total else 0.0

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 correlation_test.py <cipher.bin> <candidate_stream.bin> [bytes_to_check]")
        sys.exit(1)
    cipher_path, candidate_path = sys.argv[1], sys.argv[2]
    nbytes = int(sys.argv[3]) if len(sys.argv)>3 else 65536
    c = read_bytes(cipher_path, nbytes)
    k = read_bytes(candidate_path, nbytes)
    cb = bits_from_bytes(c)
    kb = bits_from_bytes(k)
    m,t,r = correlation(cb, kb)
    print(f"Matches: {m}/{t} -> correlation: {r:.6f}")

if __name__ == '__main__':
    main()
