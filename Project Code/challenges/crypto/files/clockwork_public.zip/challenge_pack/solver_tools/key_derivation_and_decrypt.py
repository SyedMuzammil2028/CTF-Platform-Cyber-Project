# key_derivation_and_decrypt.py
# Derive key from seed phrase using PBKDF2-HMAC-SHA256 and attempt decryption of a ciphertext using XOR keystream.
import sys
import hashlib
import binascii

def pbkdf2_hex(password, salt, iterations, dklen):
    dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), iterations, dklen)
    return binascii.hexlify(dk).decode()

def xor_bytes(a,b):
    return bytes(x^y for x,y in zip(a,b))

def main():
    if len(sys.argv) < 5:
        print('Usage: python3 key_derivation_and_decrypt.py <seed_phrase> <salt> <iterations> <cipher.bin> [out_plain.bin]')
        print('Example: python3 key_derivation_and_decrypt.py "word1|word2|word3|word4|word5" salt 100000 /mnt/data/challenge_pack/cipher.bin out.bin')
        sys.exit(1)
    seed_phrase = sys.argv[1]
    salt = sys.argv[2]
    iterations = int(sys.argv[3])
    cipher_path = sys.argv[4]
    out_path = sys.argv[5] if len(sys.argv)>5 else 'plain_out.bin'
    dk = hashlib.pbkdf2_hmac('sha256', seed_phrase.encode(), salt.encode(), iterations, dklen=32)
    print('Derived key (hex):', binascii.hexlify(dk).decode())
    with open(cipher_path,'rb') as f:
        c = f.read()
    # naive usage: XOR cipher with dk repeated to show a first-step attempt
    keystream = (dk * ((len(c)//len(dk))+1))[:len(c)]
    plain = xor_bytes(c, keystream)
    with open(out_path,'wb') as f:
        f.write(plain)
    print('Wrote tentative plaintext to', out_path)

if __name__=='__main__':
    main()
