# decrypt_sample.py
# Small utility to XOR a provided ciphertext with a provided keystream file (bytewise).
import sys
def main():
    if len(sys.argv)<4:
        print('Usage: python3 decrypt_sample.py <cipher.bin> <keystream.bin> <out_plain.bin> [nbytes]')
        sys.exit(1)
    cip, ks, out = sys.argv[1], sys.argv[2], sys.argv[3]
    n = int(sys.argv[4]) if len(sys.argv)>4 else None
    with open(cip,'rb') as f:
        c = f.read() if n is None else f.read(n)
    with open(ks,'rb') as f:
        k = f.read() if n is None else f.read(n)
    if len(k) < len(c):
        print('Warning: keystream shorter than ciphertext; output will be truncated.')
    outb = bytes(x^y for x,y in zip(c,k))
    with open(out,'wb') as f:
        f.write(outb)
    print('Written', len(outb), 'bytes to', out)

if __name__=='__main__':
    main()
